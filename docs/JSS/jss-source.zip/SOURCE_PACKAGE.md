# Typesetting package

Compile main.tex with pdfLaTeX → BibTeX → pdfLaTeX → pdfLaTeX, or run build.ps1. The sections/ and generated/ directories are required inputs and are included along with bibliography, PDF, CAS class/style files, icon assets and editable highlights.

The manuscript reports a complete fixed 50-issue, two-model study: 400 investigations and 100 controls. It retains the single-seed/reuse, defect, treatment and proxy-label limits. This archive is for typesetting, not the raw experimental replication package. See the repository's docs/JSS/AUTHOR_ACTIONS.md for declarations, environment/raw release and further validation.

Original Elsevier vendor files retain their supplied LPPL terms. No template samples were overwritten.

