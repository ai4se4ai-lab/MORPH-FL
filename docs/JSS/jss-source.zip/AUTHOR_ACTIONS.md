# Current author actions: completed-study manuscript

The current paper uses all 400 investigations and 100 retrieval controls from the fixed 50-issue study. The earlier snapshot is outside its evidence base. Historical-export restoration is therefore not a prerequisite for reproducing the current score-table results; it remains an independent historical artifact issue, preserved in `history/AUTHOR_ACTIONS-before-completed-study.md`.

## Release and submission

1. Deposit the actual evaluated v12 source, frozen protocol, exact checkpoint/dataset pins, selected IDs, labels/label generation, raw predictions, permissible traces, configurations, receipts, score files, original bootstrap report, analyzer and licenses in a durable public archive. Supply a verified URL and persistent DOI.
2. Revalidate all raw prediction contents/signatures under the hardened identity checker. Preserve October 25 receipts and distinguish them from October 28 metadata-only inspection. Current local score reconstruction is not a replacement for raw provenance validation.
3. Archive the exact evaluated Python/PyTorch/Transformers/tokenizer/CUDA/driver/OS and dependency versions, hardware allocation and clean-environment instructions. Installation version ranges are not an exact environment.
4. Confirm author list/order and postal address. Majid Babaei's supplied affiliation, email and ORCID are already applied.
5. Finalize CRediT, competing interests and funding/sponsor roles. Do not infer a negative declaration without confirmation.
6. Verify complete AI tool/version history, independently review the manuscript/analysis/references and finalize the responsibility declaration. All critical reviews here were AI simulations.
7. Complete citation/full-text verification, particularly recent preprints and the two JSS task comparisons. Do not invent publication metadata.
8. Verify the live JSS Guide and submission menu: article type, limits, anonymization/title page, source/PDF/data uploads and required forms. The source uses the supplied Elsevier CAS template; exact journal-specific requirements were not fully accessible.
9. Confirm originality, exclusive submission and any actual prior TSE submission/review/publication history.
10. Complete each visible `AUTHOR TO PROVIDE` field before submitting. No acceptance guarantee is supplied.

## Scientific work that would strengthen the paper

11. Quantify ambiguity duplicates and their prompt-token/truncation burden by condition; audit accepted-empty, source-invalid, retained and fallback outputs separately.
12. Evaluate a separately versioned correction under matched settings. Keep v12 evidence intact; reruns on the same fifty cases are development evidence.
13. Separate hypothesis exposure, behavior/relations/budget fields, serialization, dialogue and pool pruning. Changing several at once does not identify a forgetting mechanism.
14. Freeze a feasible primary estimand, clustering/precision rationale and independent confirmation sample before reading new outcomes. One seed and outcome-informed framing are not confirmatory evidence.
15. Test reset recovery with enough explicit plateau opportunities and wrong initial leads. The present study measures reset exposure and exact hit outcomes, not per-event causal recovery.
16. Add complete upstream localization and independent unstructured-agent controls for broad competitiveness claims. The current paper deliberately tests the shared harness's context policies.
17. Adjudicate targets and validate execution/causal predictions before claiming root causes. Measure developer/repair outcomes before claiming practical savings.
18. Include interrupted/retried work, setup and phase accounting for total cost claims; test independent budget settings before drawing scaling curves.
19. Add other seeds/model sizes/languages or untouched/decontaminated subjects for corresponding generalization claims.

Items 11–19 are substantive reviewer concerns and prerequisites for stronger claims. They are not reported as completed experiments. The present negative/diagnostic study remains bounded and transparent.

